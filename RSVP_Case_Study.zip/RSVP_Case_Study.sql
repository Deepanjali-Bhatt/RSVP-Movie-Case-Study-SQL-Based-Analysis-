USE imdb;

/* Now that you have imported the data sets, let’s explore some of the tables. 
 To begin with, it is beneficial to know the shape of the tables and whether any column has null values.
 Further in this segment, you will take a look at 'movies' and 'genre' tables.*/



-- Segment 1:




-- Q1. Find the total number of rows in each table of the schema?
-- Type your code below:

-- Query to get the total number of rows from multiple tables
-- Query to get the total number of rows in each table

SELECT 
    'director_mapping' AS Table_Name, -- Name of the 'director_mapping' table
    COUNT(*) AS Total_No_of_Rows -- Total rows in the 'director_mapping' table
FROM director_mapping

UNION ALL

SELECT 
    'genre' AS Table_Name, -- Name of the 'genre' table
    COUNT(*) AS Total_No_of_Rows -- Total rows in the 'genre' table
FROM genre

UNION ALL

SELECT 
    'movie' AS Table_Name, -- Name of the 'movie' table
    COUNT(*) AS Total_No_of_Rows -- Total rows in the 'movie' table
FROM movie

UNION ALL

SELECT 
    'names' AS Table_Name, -- Name of the 'names' table
    COUNT(*) AS Total_No_of_Rows -- Total rows in the 'names' table
FROM names

UNION ALL

SELECT 
    'ratings' AS Table_Name, -- Name of the 'ratings' table
    COUNT(*) AS Total_No_of_Rows -- Total rows in the 'ratings' table
FROM ratings

UNION ALL

SELECT 
    'role_mapping' AS Table_Name, -- Name of the 'role_mapping' table
    COUNT(*) AS Total_No_of_Rows -- Total rows in the 'role_mapping' table
FROM role_mapping;




-- Q2. Which columns in the movie table have null values?
-- Type your code below:

-- Query to count null values for various columns in the movie table
SELECT
    -- Counting null values in the 'id' column
    SUM(CASE WHEN id IS NULL THEN 1 ELSE 0 END) AS id_null_values_count,

    -- Counting null values in the 'title' column
    SUM(CASE WHEN title IS NULL THEN 1 ELSE 0 END) AS title_null_values_count,

    -- Counting null values in the 'year' column
    SUM(CASE WHEN year IS NULL THEN 1 ELSE 0 END) AS year_null_values_count,

    -- Counting null values in the 'date_published' column
    SUM(CASE WHEN date_published IS NULL THEN 1 ELSE 0 END) AS date_published_null_values_count,

    -- Counting null values in the 'duration' column
    SUM(CASE WHEN duration IS NULL THEN 1 ELSE 0 END) AS duration_null_values_count,

    -- Counting null values in the 'country' column
    SUM(CASE WHEN country IS NULL THEN 1 ELSE 0 END) AS country_null_values_count,

    -- Counting null values in the 'worldwide_gross_income' column
    SUM(CASE WHEN worlwide_gross_income IS NULL THEN 1 ELSE 0 END) AS worldwide_gross_income_null_values_count,

    -- Counting null values in the 'languages' column
    SUM(CASE WHEN languages IS NULL THEN 1 ELSE 0 END) AS languages_null_values_count,

    -- Counting null values in the 'production_company' column
    SUM(CASE WHEN production_company IS NULL THEN 1 ELSE 0 END) AS production_company_null_values_count
FROM movie;  -- From the movie table






-- Now as you can see four columns of the movie table has null values. Let's look at the at the movies released each year. 
-- Q3. Find the total number of movies released each year? How does the trend look month wise? (Output expected)

/* Output format for the first part:

+---------------+-------------------+
| Year			|	number_of_movies|
+-------------------+----------------
|	2017		|	2134			|
|	2018		|		.			|
|	2019		|		.			|
+---------------+-------------------+


Output format for the second part of the question:
+---------------+-------------------+
|	month_num	|	number_of_movies|
+---------------+----------------
|	1			|	 134			|
|	2			|	 231			|
|	.			|		.			|
+---------------+-------------------+ */
-- Type your code below:

-- PART 1: Count number of movies released each year
SELECT 
    year,  -- Select the year of release
    COUNT(id) AS number_of_movies  -- Count the total number of movies released in that year
FROM movie  -- From the movie table
GROUP BY year  -- Group by year to count the number of movies released in each year
ORDER BY year;  -- Order the result by year in ascending order

-- PART 2: Count number of movies released each month
SELECT 
    MONTH(date_published) AS month_num,  -- Extract the month number from the date_published column
    COUNT(id) AS number_of_movies  -- Count the number of movies released in each month
FROM movie  -- From the movie table
GROUP BY month_num  -- Group by month number to count movies released each month
ORDER BY number_of_movies DESC;  -- Order the result by the number of movies in descending order




/*The highest number of movies is produced in the month of March.
So, now that you have understood the month-wise trend of movies, let’s take a look at the other details in the movies table. 
We know USA and India produces huge number of movies each year. Lets find the number of movies produced by USA or India for the last year.*/
  
-- Q4. How many movies were produced in the USA or India in the year 2019??
-- Type your code below:

-- Query to count the number of movies from India or USA in 2019

SELECT COUNT(id) AS No_of_movies  -- Count the total number of movies
FROM movie  -- From the movie table
WHERE (country LIKE '%INDIA%' OR country LIKE '%USA%')  -- Where the country is either India or USA
  AND year = 2019;  -- And the year is 2019





/* USA and India produced more than a thousand movies(you know the exact number!) in the year 2019.
Exploring table Genre would be fun!! 
Let’s find out the different genres in the dataset.*/

-- Q5. Find the unique list of the genres present in the data set?
-- Type your code below:

-- Query to retrieve distinct genres from the genre table
SELECT DISTINCT genre  -- Select unique genres from the genre table
FROM genre;  -- From the genre table




/* So, RSVP Movies plans to make a movie of one of these genres.
Now, wouldn’t you want to know which genre had the highest number of movies produced in the last year?
Combining both the movie and genres table can give more interesting insights. */

-- Q6.Which genre had the highest number of movies produced overall?
-- Type your code below:

-- Query to get the top 3 genres with the highest number of movies

SELECT 
    genre,  -- Select genre column from the genre table
    COUNT(m.id) AS Total_No_of_movies  -- Count the number of movies for each genre
FROM movie m  -- From the movie table
INNER JOIN genre g  -- Join with the genre table
    ON m.id = g.movie_id  -- Match movies to their respective genres
GROUP BY genre  -- Group the data by genre to get the count of movies per genre
ORDER BY Total_No_of_movies DESC  -- Order the result by the total number of movies in descending order
LIMIT 3;  -- Limit the result to the top 3 genres with the most movies




/* So, based on the insight that you just drew, RSVP Movies should focus on the ‘Drama’ genre. 
But wait, it is too early to decide. A movie can belong to two or more genres. 
So, let’s find out the count of movies that belong to only one genre.*/

-- Q7. How many movies belong to only one genre?
-- Type your code below:


-- Query to count the number of movies that are associated with only one genre

WITH unique_movie AS (  -- Creating a common table expression (CTE) named unique_movie
    SELECT 
        movie_id,  -- Select the movie_id from the genre table
        COUNT(genre) AS Total_no_of_genre  -- Count the number of genres associated with each movie
    FROM genre  -- From the genre table
    GROUP BY movie_id  -- Group by movie_id to get the genre count per movie
)

-- Final query to count movies with only one genre
SELECT COUNT(*) AS Movie_with_only_one_genre  -- Count the number of movies with exactly one genre
FROM unique_movie  -- From the CTE created above
WHERE Total_no_of_genre = 1;  -- Filter only those movies that are associated with exactly one genre





/* There are more than three thousand movies which has only one genre associated with them.
So, this figure appears significant. 
Now, let's find out the possible duration of RSVP Movies’ next project.*/

-- Q8.What is the average duration of movies in each genre? 
-- (Note: The same movie can belong to multiple genres.)


/* Output format:

+---------------+-------------------+
| genre			|	avg_duration	|
+-------------------+----------------
|	thriller	|		105			|
|	.			|		.			|
|	.			|		.			|
+---------------+-------------------+ */
-- Type your code below:

-- Query to calculate the average movie duration for each genre
-- Query to calculate the average movie duration for each genre

SELECT 
    genre,  -- Select the genre from the genre table
    ROUND(AVG(duration), 2) AS avg_duration  -- Calculate the average duration of movies and round it to 2 decimal places
FROM movie m  -- From the movie table
INNER JOIN genre g  -- Inner join the movie table with the genre table
    ON m.id = g.movie_id  -- Join condition: movies are linked to their genres via movie_id
GROUP BY genre;  -- Group by genre to calculate the average duration for each genre





/* Now you know, movies of genre 'Drama' (produced highest in number in 2019) has the average duration of 106.77 mins.
Lets find where the movies of genre 'thriller' on the basis of number of movies.*/

-- Q9.What is the rank of the ‘thriller’ genre of movies among all the genres in terms of number of movies produced? 
-- (Hint: Use the Rank function)


/* Output format:
+---------------+-------------------+---------------------+
| genre			|		movie_count	|		genre_rank    |	
+---------------+-------------------+---------------------+
|drama			|	2312			|			2		  |
+---------------+-------------------+---------------------+*/
-- Type your code below:

-- CTE to rank genres based on movie count
-- Query to rank genres based on the number of movies associated with each genre

WITH genre_rank AS (  -- Creating a common table expression (CTE) named genre_rank
    SELECT 
        genre,  -- Select the genre column
        COUNT(m.id) AS movie_count,  -- Count the number of movies for each genre
        ROW_NUMBER() OVER (ORDER BY COUNT(m.id) DESC) AS genre_rank  -- Rank genres by movie count in descending order
    FROM movie m  -- From the movie table
    INNER JOIN genre g ON m.id = g.movie_id  -- Inner join with the genre table to associate movies with their genres
    GROUP BY genre  -- Group by genre to get the count of movies for each genre
)

-- Select the rank and movie count for the 'Thriller' genre
-- Query to retrieve genre ranking information for the 'Thriller' genre from the genre_rank table

SELECT *  -- Select all columns from the genre_rank table
FROM genre_rank  -- From the genre_rank table
WHERE genre = 'Thriller';  -- Filter the results to include only rows where the genre is 'Thriller'


/*Thriller movies is in top 3 among all genres in terms of number of movies
 In the previous segment, you analysed the movies and genres tables. 
 In this segment, you will analyse the ratings table as well.
To start with lets get the min and max values of different columns in the table*/




-- Segment 2:




-- Q10.  Find the minimum and maximum values in  each column of the ratings table except the movie_id column?
/* Output format:
+---------------+-------------------+---------------------+----------------------+-----------------+-----------------+
| min_avg_rating|	max_avg_rating	|	min_total_votes   |	max_total_votes 	 |min_median_rating|min_median_rating|
+---------------+-------------------+---------------------+----------------------+-----------------+-----------------+
|		0		|			5		|	       177		  |	   2000	    		 |		0	       |	8			 |
+---------------+-------------------+---------------------+----------------------+-----------------+-----------------+*/
-- Type your code below:

-- Query to find the minimum and maximum ratings, votes, and median ratings from the ratings table
-- Query to find the minimum and maximum values for avg_rating, total_votes, and median_rating from the ratings table

SELECT 
    MIN(avg_rating) AS min_avg_rating,  -- Selecting the minimum average rating
    MAX(avg_rating) AS max_avg_rating,  -- Selecting the maximum average rating
    MIN(total_votes) AS min_total_votes,  -- Selecting the minimum total votes
    MAX(total_votes) AS max_total_votes,  -- Selecting the maximum total votes
    MIN(median_rating) AS min_median_rating,  -- Selecting the minimum median rating
    MAX(median_rating) AS max_median_rating  -- Selecting the maximum median rating
FROM ratings;  -- From the ratings table

-- Note : assuming the output format given by upgrad wrote 'min_median_rating' by mistake



    

/* So, the minimum and maximum values in each column of the ratings table are in the expected range. 
This implies there are no outliers in the table. 
Now, let’s find out the top 10 movies based on average rating.*/

-- Q11. Which are the top 10 movies based on average rating?
/* Output format:
+---------------+-------------------+---------------------+
| title			|		avg_rating	|		movie_rank    |
+---------------+-------------------+---------------------+
| Fan			|		9.6			|			5	  	  |
|	.			|		.			|			.		  |
|	.			|		.			|			.		  |
|	.			|		.			|			.		  |
+---------------+-------------------+---------------------+*/
-- Type your code below:
-- Keep in mind that multiple movies can be at the same rank. You only have to find out the top 10 movies (if there are more than one movies at the 10th place, consider them all.)

-- Query to get the top 10 movies by average rating with their rank
-- Query to retrieve the top 10 movies based on avg_rating and assign ranks

SELECT 
    m.title,  -- Selecting the movie title from the movie table
    r.avg_rating,  -- Selecting the average rating from the ratings table
    ROW_NUMBER() OVER (ORDER BY r.avg_rating DESC) AS movie_rank  -- Assigning a rank to each movie based on avg_rating in descending order
FROM ratings r
INNER JOIN movie m ON r.movie_id = m.id  -- Joining ratings table with movie table based on movie_id
LIMIT 10;  -- Limiting the results to the top 10 movies based on their avg_rating






/* Do you find you favourite movie FAN in the top 10 movies with an average rating of 9.6? If not, please check your code again!!
So, now that you know the top 10 movies, do you think character actors and filler actors can be from these movies?
Summarising the ratings table based on the movie counts by median rating can give an excellent insight.*/

-- Q12. Summarise the ratings table based on the movie counts by median ratings.
/* Output format:

+---------------+-------------------+
| median_rating	|	movie_count		|
+-------------------+----------------
|	1			|		105			|
|	.			|		.			|
|	.			|		.			|
+---------------+-------------------+ */
-- Type your code below:
-- Order by is good to have

-- Query to get the count of movies for each median rating
SELECT 
    median_rating, -- The median rating of the movie
    COUNT(m.id) AS movie_count -- The number of movies with that median rating
FROM ratings r
INNER JOIN movie m ON m.id = r.movie_id -- Joining 'ratings' table with 'movie' table based on movie_id
GROUP BY median_rating -- Grouping the result by median_rating to get the count of movies for each rating
ORDER BY movie_count DESC; -- Ordering the result by movie count in descending order






/* Movies with a median rating of 7 is highest in number. 
Now, let's find out the production house with which RSVP Movies can partner for its next project.*/

-- Q13. Which production house has produced the most number of hit movies (average rating > 8)??
/* Output format:
+------------------+-------------------+---------------------+
|production_company|movie_count	       |	prod_company_rank|
+------------------+-------------------+---------------------+
| The Archers	   |		1		   |			1	  	 |
+------------------+-------------------+---------------------+*/
-- Type your code below:

-- Query to get the ranking of production companies based on the number of movies with an avg_rating > 8

SELECT 
    production_company,  -- Selecting the name of the production company
    COUNT(m.id) AS movie_count,  -- Counting the number of movies for each production company
    RANK() OVER (ORDER BY COUNT(m.id) DESC) AS prod_company_rank  -- Assigning a rank to the production company based on movie count in descending order
FROM movie m 
INNER JOIN ratings r ON m.id = r.movie_id  -- Joining movie table with ratings table to get the average ratings
WHERE r.avg_rating > 8  -- Filtering for movies with average rating greater than 8
    AND production_company IS NOT NULL  -- Excluding rows where the production company is null
GROUP BY production_company  -- Grouping the results by production company to count the movies
ORDER BY prod_company_rank;  -- Ordering the results by the rank of the production company






-- It's ok if RANK() or DENSE_RANK() is used too
-- Answer can be Dream Warrior Pictures or National Theatre Live or both

-- Q14. How many movies released in each genre during March 2017 in the USA had more than 1,000 votes?
/* Output format:

+---------------+-------------------+
| genre			|	movie_count		|
+-------------------+----------------
|	thriller	|		105			|
|	.			|		.			|
|	.			|		.			|
+---------------+-------------------+ */
-- Type your code below:

-- Query to get the count of movies for each genre in March 2017 from USA with more than 1000 votes
SELECT 
    genre, -- The genre of the movie
    COUNT(m.id) AS movie_count -- The count of movies for each genre
FROM genre g
INNER JOIN movie m 
    ON g.movie_id = m.id -- Join 'genre' with 'movie' on movie_id
INNER JOIN ratings r 
    ON m.id = r.movie_id -- Join 'movie' with 'ratings' on movie_id
WHERE 
    MONTH(m.date_published) = 3 -- Filter for movies published in March
    AND YEAR(m.date_published) = 2017 -- Filter for movies published in the year 2017
    AND r.total_votes > 1000 -- Filter for movies with more than 1000 votes
    AND m.country LIKE '%USA%' -- Filter for movies from the USA
GROUP BY genre -- Group by genre to get the count for each genre
ORDER BY movie_count DESC; -- Order the results by movie count in descending order




-- Lets try to analyse with a unique problem statement.
-- Q15. Find movies of each genre that start with the word ‘The’ and which have an average rating > 8?
/* Output format:
+---------------+-------------------+---------------------+
| title			|		avg_rating	|		genre	      |
+---------------+-------------------+---------------------+
| Theeran		|		8.3			|		Thriller	  |
|	.			|		.			|			.		  |
|	.			|		.			|			.		  |
|	.			|		.			|			.		  |
+---------------+-------------------+---------------------+*/
-- Type your code below:

-- Query to get movies starting with 'The' and with an average rating greater than 8
SELECT 
    m.title, -- Movie title
    r.avg_rating, -- Average rating of the movie
    g.genre -- Genre of the movie
FROM movie m
INNER JOIN ratings r 
    ON m.id = r.movie_id -- Join 'movie' with 'ratings' on movie_id
INNER JOIN genre g 
    ON m.id = g.movie_id -- Join 'movie' with 'genre' on movie_id
WHERE 
    m.title LIKE 'The%' -- Filter for movie titles starting with 'The'
    AND r.avg_rating > 8 -- Filter for movies with an average rating greater than 8
ORDER BY 
    r.avg_rating DESC; -- Order the results by average rating in descending order




-- You should also try your hand at median rating and check whether the ‘median rating’ column gives any significant insights.
-- Q16. Of the movies released between 1 April 2018 and 1 April 2019, how many were given a median rating of 8?
-- Type your code below:

-- Query to count movies released between April 2018 and April 2019 with a median rating of 8
SELECT 
    COUNT(id) AS movie_released_between_april2018_and_april2019 -- Count of movies
FROM movie m
INNER JOIN ratings r 
    ON m.id = r.movie_id -- Join 'movie' and 'ratings' on movie_id
WHERE 
    (date_published BETWEEN '2018-04-01' AND '2019-04-01') -- Filter for movies released between April 1, 2018, and April 1, 2019
    AND median_rating = 8; -- Filter for movies with a median rating of 8




-- Once again, try to solve the problem given below.
-- Q17. Do German movies get more votes than Italian movies? 
-- Hint: Here you have to find the total number of votes for both German and Italian movies.
-- Type your code below:

-- Query to sum the total number of votes for movies from Germany and Italy
SELECT 
    country, -- The country of the movie
    SUM(total_votes) AS Total_no_of_votes -- Total number of votes for movies from that country
FROM movie m
INNER JOIN ratings r 
    ON m.id = r.movie_id -- Join 'movie' and 'ratings' on movie_id
WHERE 
    country IN ('Germany', 'Italy') -- Filter for movies from Germany or Italy
GROUP BY country; -- Group the results by country




-- Answer is Yes

/* Now that you have analysed the movies, genres and ratings tables, let us now analyse another table, the names table. 
Let’s begin by searching for null values in the tables.*/




-- Segment 3:



-- Q18. Which columns in the names table have null values??
/*Hint: You can find null values for individual columns or follow below output format
+---------------+-------------------+---------------------+----------------------+
| name_nulls	|	height_nulls	|date_of_birth_nulls  |known_for_movies_nulls|
+---------------+-------------------+---------------------+----------------------+
|		0		|			123		|	       1234		  |	   12345	    	 |
+---------------+-------------------+---------------------+----------------------+*/
-- Type your code below:

-- Query to count the number of null values in specific columns in the 'names' table
SELECT 
    SUM(CASE WHEN name IS NULL THEN 1 ELSE 0 END) AS name_nulls, -- Count null values in the 'name' column
    SUM(CASE WHEN height IS NULL THEN 1 ELSE 0 END) AS height_nulls, -- Count null values in the 'height' column
    SUM(CASE WHEN date_of_birth IS NULL THEN 1 ELSE 0 END) AS date_of_birth_nulls, -- Count null values in 'date_of_birth'
    SUM(CASE WHEN known_for_movies IS NULL THEN 1 ELSE 0 END) AS known_for_movies_nulls -- Count null values in 'known_for_movies'
FROM names; -- The 'names' table contains the data we are analyzing




/* There are no Null value in the column 'name'.
The director is the most important person in a movie crew. 
Let’s find out the top three directors in the top three genres who can be hired by RSVP Movies.*/

-- Q19. Who are the top three directors in the top three genres whose movies have an average rating > 8?
-- (Hint: The top three genres would have the most number of movies with an average rating > 8.)
/* Output format:

+---------------+-------------------+
| director_name	|	movie_count		|
+---------------+-------------------|
|James Mangold	|		4			|
|	.			|		.			|
|	.			|		.			|
+---------------+-------------------+ */
-- Type your code below:

-- First, create a temporary result set (top_three_genre) with the top 3 genres based on the count of movies with an average rating above 8
-- First, create a temporary result set (top_three_genre) with the top 3 genres based on the count of movies with an average rating above 8
WITH top_three_genre AS (
    SELECT 
        genre, 
        COUNT(m.id) AS movie_count  -- Count of movies in each genre with avg_rating > 8
    FROM movie m 
    INNER JOIN genre g 
        ON m.id = g.movie_id  -- Join with genre to get the genre for each movie
    INNER JOIN ratings r 
        ON r.movie_id = m.id  -- Join with ratings to filter movies with avg_rating > 8
    WHERE avg_rating > 8  -- Only consider movies with an avg_rating > 8
    GROUP BY genre  -- Group by genre
    ORDER BY movie_count DESC  -- Order genres by the movie count in descending order
    LIMIT 3  -- Limit to the top 3 genres
)
-- Now, query to get the top 3 directors who have directed movies in the top 3 genres and have an average rating above 8
SELECT 
    n.name AS director_name,  -- Director's name
    COUNT(m.id) AS movie_count  -- Count of movies directed by this director in the top 3 genres with avg_rating > 8
FROM movie m 
INNER JOIN director_mapping d 
    ON m.id = d.movie_id  -- Join with director_mapping to get the director for each movie
INNER JOIN names n  
    ON n.id = d.name_id  -- Join with names to get the director's name
INNER JOIN genre g 
    ON g.movie_id = m.id  -- Join with genre to get the genre of each movie
INNER JOIN ratings r 
    ON m.id = r.movie_id  -- Join with ratings to filter movies with avg_rating > 8
WHERE g.genre IN (SELECT genre FROM top_three_genre)  -- Only include movies from the top 3 genres
    AND avg_rating > 8  -- Only consider movies with an avg_rating > 8
GROUP BY director_name  -- Group by director's name
ORDER BY movie_count DESC  -- Order by the count of movies directed in the top 3 genres
LIMIT 3;  -- Limit to the top 3 directors



/* James Mangold can be hired as the director for RSVP's next project. Do you remeber his movies, 'Logan' and 'The Wolverine'. 
Now, let’s find out the top two actors.*/

-- Q20. Who are the top two actors whose movies have a median rating >= 8?
/* Output format:

+---------------+-------------------+
| actor_name	|	movie_count		|
+-------------------+----------------
|Christain Bale	|		10			|
|	.			|		.			|
+---------------+-------------------+ */
-- Type your code below:


-- Query to get the top 2 actors with the most movies and average rating above 8
SELECT 
    n.name AS actor_name, -- Actor's name
    COUNT(m.id) AS movie_count -- Total number of movies the actor has acted in
FROM movie m 
INNER JOIN ratings r 
    ON m.id = r.movie_id -- Join to access ratings for each movie
INNER JOIN role_mapping rm 
    ON m.id = rm.movie_id -- Join to get roles mapped to movies
INNER JOIN names n 
    ON n.id = rm.name_id -- Join to get actor names
WHERE 
    r.median_rating >= 8 -- Filter for movies with median_rating of 8 or above (assuming median_rating is a valid column)
GROUP BY 
    actor_name -- Group by actor to count the number of movies
ORDER BY 
    movie_count DESC -- Order by movie count in descending order
LIMIT 2; -- Limit the result to top 2 actors with the most movies





/* Have you find your favourite actor 'Mohanlal' in the list. If no, please check your code again. 
RSVP Movies plans to partner with other global production houses. 
Let’s find out the top three production houses in the world.*/

-- Q21. Which are the top three production houses based on the number of votes received by their movies?
/* Output format:
+------------------+--------------------+---------------------+
|production_company|vote_count			|		prod_comp_rank|
+------------------+--------------------+---------------------+
| The Archers		|		830			|		1	  		  |
|	.				|		.			|			.		  |
|	.				|		.			|			.		  |
+-------------------+-------------------+---------------------+*/
-- Type your code below:

-- Query to rank production companies based on total votes across their movies
SELECT 
    m.production_company, -- Name of the production company
    SUM(r.total_votes) AS vote_count, -- Total number of votes across all movies of the company
    ROW_NUMBER() OVER (
        ORDER BY SUM(r.total_votes) DESC
    ) AS prod_comp_rank -- Rank production companies based on total votes, in descending order
FROM movie m
INNER JOIN ratings r 
    ON m.id = r.movie_id -- Join to get the ratings for each movie
GROUP BY 
    m.production_company -- Group by production company to aggregate vote counts
LIMIT 3; -- Limit the results to the top 3 production companies based on total votes





/*Yes Marvel Studios rules the movie world.
So, these are the top three production houses based on the number of votes received by the movies they have produced.

Since RSVP Movies is based out of Mumbai, India also wants to woo its local audience. 
RSVP Movies also wants to hire a few Indian actors for its upcoming project to give a regional feel. 
Let’s find who these actors could be.*/

-- Q22. Rank actors with movies released in India based on their average ratings. Which actor is at the top of the list?
-- Note: The actor should have acted in at least five Indian movies. 
-- (Hint: You should use the weighted average based on votes. If the ratings clash, then the total number of votes should act as the tie breaker.)

/* Output format:
+---------------+-------------------+---------------------+----------------------+-----------------+
| actor_name	|	total_votes		|	movie_count		  |	actor_avg_rating 	 |actor_rank	   |
+---------------+-------------------+---------------------+----------------------+-----------------+
|	Yogi Babu	|			3455	|	       11		  |	   8.42	    		 |		1	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
+---------------+-------------------+---------------------+----------------------+-----------------+*/
-- Type your code below:


-- Query to rank actors based on weighted average rating and total votes
SELECT 
    n.name AS actor_name, -- Name of the actor
    SUM(r.total_votes) AS total_votes, -- Total votes across all movies
    COUNT(m.id) AS movie_count, -- Total number of movies acted in
    ROUND(SUM(r.avg_rating * r.total_votes) / SUM(r.total_votes), 2) AS actor_avg_rating, 
    -- Weighted average rating for the actor (weighted by total votes)
    ROW_NUMBER() OVER (
        ORDER BY 
            ROUND(SUM(r.avg_rating * r.total_votes) / SUM(r.total_votes), 2) DESC
    ) AS actor_rank -- Rank actors by weighted average rating in descending order
FROM names n
INNER JOIN role_mapping rm 
    ON n.id = rm.name_id -- Join to map roles with names
INNER JOIN ratings r 
    ON rm.movie_id = r.movie_id -- Join to access ratings for movies
INNER JOIN movie m 
    ON m.id = rm.movie_id -- Join to access movie details
WHERE 
    rm.category = 'actor' -- Filter for roles categorized as actors
    AND m.country LIKE "%india%" -- Filter for movies produced in India
GROUP BY 
    n.name -- Group by actor name to calculate aggregates
HAVING 
    COUNT(m.id) >= 5; -- Include only actors with at least 5 movies




-- Top actor is Vijay Sethupathi

-- Q23.Find out the top five actresses in Hindi movies released in India based on their average ratings? 
-- Note: The actresses should have acted in at least three Indian movies. 
-- (Hint: You should use the weighted average based on votes. If the ratings clash, then the total number of votes should act as the tie breaker.)
/* Output format:
+---------------+-------------------+---------------------+----------------------+-----------------+
| actress_name	|	total_votes		|	movie_count		  |	actress_avg_rating 	 |actress_rank	   |
+---------------+-------------------+---------------------+----------------------+-----------------+
|	Tabu		|			3455	|	       11		  |	   8.42	    		 |		1	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
+---------------+-------------------+---------------------+----------------------+-----------------+*/
-- Type your code below:

-- Query to rank actresses based on weighted average rating and total votes
SELECT 
    n.name AS actress_name, -- Name of the actress
    SUM(r.total_votes) AS total_votes, -- Total votes across all movies
    COUNT(m.id) AS movie_count, -- Total number of movies acted in
    ROUND(SUM(r.avg_rating * r.total_votes) / SUM(r.total_votes), 2) AS actress_avg_rating, 
    -- Weighted average rating for the actress (weighted by total votes)
    ROW_NUMBER() OVER (
        ORDER BY 
            ROUND(SUM(r.avg_rating * r.total_votes) / SUM(r.total_votes), 2) DESC, 
            SUM(r.total_votes) DESC
    ) AS actress_rank -- Rank actresses by weighted average rating, then by total votes
FROM names n
INNER JOIN role_mapping rm 
    ON n.id = rm.name_id -- Join to map roles with names
INNER JOIN ratings r 
    ON rm.movie_id = r.movie_id -- Join to access ratings for movies
INNER JOIN movie m 
    ON m.id = rm.movie_id -- Join to access movie details
WHERE 
    rm.category = 'actress' -- Filter for roles categorized as actresses
    AND m.country LIKE "%india%" -- Filter for movies produced in India
    AND m.languages LIKE "%hindi%" -- Filter for movies in the Hindi language
GROUP BY 
    n.name -- Group by actress name to calculate aggregates
HAVING 
    COUNT(m.id) >= 3 -- Include only actresses with at least 3 movies




/* Taapsee Pannu tops with average rating 7.74. 
Now let us divide all the thriller movies in the following categories and find out their numbers.*/


/* Q24. Consider thriller movies having at least 25,000 votes. Classify them according to their average ratings in
   the following categories:  

			Rating > 8: Superhit
			Rating between 7 and 8: Hit
			Rating between 5 and 7: One-time-watch
			Rating < 5: Flop
	
    Note: Sort the output by average ratings (desc).
--------------------------------------------------------------------------------------------*/
/* Output format:
+---------------+-------------------+
| movie_name	|	movie_category	|
+---------------+-------------------+
|	Get Out		|			Hit		|
|		.		|			.		|
|		.		|			.		|
+---------------+-------------------+*/

-- Type your code below:


-- Query to categorize movies based on their average rating
SELECT 
    m.title AS movie_name, -- Movie title
    CASE 
        WHEN r.avg_rating > 8 THEN 'Super Hit' -- Movies with average rating above 8
        WHEN r.avg_rating BETWEEN 7 AND 8 THEN 'Hit' -- Movies with average rating between 7 and 8
        WHEN r.avg_rating BETWEEN 5 AND 7 THEN 'One Time Watch' -- Movies with average rating between 5 and 7
        WHEN r.avg_rating < 5 THEN 'Flop' -- Movies with average rating below 5
    END AS movie_category -- Category of the movie based on average rating
FROM movie m
INNER JOIN genre g 
    ON m.id = g.movie_id -- Join to associate movies with their genres
INNER JOIN ratings r 
    ON r.movie_id = m.id -- Join to get movie ratings
WHERE 
    g.genre = 'Thriller' -- Filter for movies in the Thriller genre
    AND r.total_votes >= 25000 -- Include movies with at least 25,000 votes
ORDER BY 
    r.avg_rating DESC; -- Sort movies by average rating in descending order






/* Until now, you have analysed various tables of the data set. 
Now, you will perform some tasks that will give you a broader understanding of the data in this segment.*/

-- Segment 4:

-- Q25. What is the genre-wise running total and moving average of the average movie duration? 
-- (Note: You need to show the output table in the question.) 
/* Output format:
+---------------+-------------------+---------------------+----------------------+
| genre			|	avg_duration	|running_total_duration|moving_avg_duration  |
+---------------+-------------------+---------------------+----------------------+
|	comdy		|			145		|	       106.2	  |	   128.42	    	 |
|		.		|			.		|	       .		  |	   .	    		 |
|		.		|			.		|	       .		  |	   .	    		 |
|		.		|			.		|	       .		  |	   .	    		 |
+---------------+-------------------+---------------------+----------------------+*/
-- Type your code below:

-- Query to calculate average duration, running total of durations, and moving average of durations by genre
SELECT 
    g.genre, -- Genre of the movie
    ROUND(AVG(m.duration), 2) AS avg_duration, -- Average duration of movies in the genre, rounded to 2 decimal places
    SUM(ROUND(AVG(m.duration), 2)) 
        OVER (ORDER BY g.genre) AS running_total_duration, -- Running total of average durations by genre
    ROUND(
        AVG(ROUND(AVG(m.duration), 2)) 
        OVER (ORDER BY g.genre ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW), 2
    ) AS moving_avg_duration -- Moving average of average durations by genre
FROM movie m
INNER JOIN genre g 
    ON m.id = g.movie_id -- Join movies with their genres
GROUP BY g.genre -- Group by genre to calculate aggregates
ORDER BY g.genre; -- Sort the results by genre






-- Round is good to have and not a must have; Same thing applies to sorting


-- Let us find top 5 movies of each year with top 3 genres.

-- Q26. Which are the five highest-grossing movies of each year that belong to the top three genres? 
-- (Note: The top 3 genres would have the most number of movies.)

/* Output format:
+---------------+-------------------+---------------------+----------------------+-----------------+
| genre			|	year			|	movie_name		  |worldwide_gross_income|movie_rank	   |
+---------------+-------------------+---------------------+----------------------+-----------------+
|	comedy		|			2017	|	       indian	  |	   $103244842	     |		1	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
+---------------+-------------------+---------------------+----------------------+-----------------+*/
-- Type your code below:

-- Top 3 Genres based on most number of movies



-- CTE to find the top three genres based on the number of movies
WITH top_three_genre AS (
    SELECT 
        g.genre, -- Genre name
        COUNT(m.id) AS movie_count -- Total number of movies in the genre
    FROM movie m
    INNER JOIN genre g 
        ON g.movie_id = m.id -- Join movies with their genres
    GROUP BY g.genre -- Group by genre to count the number of movies
    ORDER BY movie_count DESC -- Sort genres by movie count in descending order
    LIMIT 3 -- Limit to the top 3 genres
),

-- CTE to create the final table with the top movies per year for the top genres
final_table AS (
    SELECT 
        g.genre, -- Genre of the movie
        m.year, -- Release year of the movie
        m.title AS movie_name, -- Movie title
        m.worlwide_gross_income AS worldwide_gross_income, -- Worldwide gross income of the movie
        ROW_NUMBER() OVER (PARTITION BY m.year ORDER BY m.worlwide_gross_income DESC) AS movie_rank 
        -- Rank movies within the same year by their worldwide gross income in descending order
    FROM movie m
    INNER JOIN genre g 
        ON g.movie_id = m.id -- Join movies with their genres
    WHERE 
        g.genre IN (SELECT genre FROM top_three_genre) -- Filter to include only the top 3 genres
)

-- Select the top 5 movies per year based on their rank
SELECT 
    *
FROM final_table
WHERE movie_rank <= 5; -- Limit to the top 5 ranked movies per year





-- Finally, let’s find out the names of the top two production houses that have produced the highest number of hits among multilingual movies.
-- Q27.  Which are the top two production houses that have produced the highest number of hits (median rating >= 8) among multilingual movies?
/* Output format:
+-------------------+-------------------+---------------------+
|production_company |movie_count		|		prod_comp_rank|
+-------------------+-------------------+---------------------+
| The Archers		|		830			|		1	  		  |
|	.				|		.			|			.		  |
|	.				|		.			|			.		  |
+-------------------+-------------------+---------------------+*/
-- Type your code below:

-- CTE to identify top production houses based on movie count with additional filters
WITH top_production_house AS (
    SELECT 
        m.production_company, -- Production company name
        COUNT(*) AS movie_count, -- Total number of movies produced
        ROW_NUMBER() OVER (ORDER BY COUNT(*) DESC) AS prod_comp_rank -- Rank based on movie count
    FROM movie m
    INNER JOIN ratings r 
        ON m.id = r.movie_id -- Join to access movie ratings
    WHERE 
        r.median_rating >= 8 -- Filter for movies with a median rating of 8 or higher
        AND POSITION(',' IN m.languages) > 0 -- Include movies with multiple languages (comma-separated)
        AND m.production_company IS NOT NULL -- Exclude movies with no production company listed
    GROUP BY 
        m.production_company -- Group by production company for aggregation
)

-- Select the top 2 production houses based on rank
SELECT 
    production_company, -- Production company name
    movie_count, -- Total number of movies produced
    prod_comp_rank -- Rank of the production company
FROM top_production_house
WHERE prod_comp_rank <= 2; -- Limit results to the top 2 ranked production houses




-- Multilingual is the important piece in the above question. It was created using POSITION(',' IN languages)>0 logic
-- If there is a comma, that means the movie is of more than one language


-- Q28. Who are the top 3 actresses based on the number of Super Hit movies (Superhit movie: average rating of movie > 8) in 'drama' genre?

-- Note: Consider only superhit movies to calculate the actress average ratings.
-- (Hint: You should use the weighted average based on votes. If the ratings clash, then the total number of votes
-- should act as the tie breaker. If number of votes are same, sort alphabetically by actress name.)

/* Output format:
+---------------+-------------------+---------------------+----------------------+-----------------+
| actress_name	|	total_votes		|	movie_count		  |	  actress_avg_rating |actress_rank	   |
+---------------+-------------------+---------------------+----------------------+-----------------+
|	Laura Dern	|			1016	|	       1		  |	   9.6000		     |		1	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
|		.		|			.		|	       .		  |	   .	    		 |		.	       |
+---------------+-------------------+---------------------+----------------------+-----------------+*/

-- Type your code below:

-- Select actress details along with total votes, movie count, and average rating
SELECT 
    n.name AS actress_name, -- Actress name
    SUM(r.total_votes) AS total_votes, -- Total votes received for all her movies
    COUNT(m.id) AS movie_count, -- Total number of movies
    AVG(r.avg_rating) AS actress_avg_rating, -- Average rating of all her movies
    ROW_NUMBER() OVER (ORDER BY COUNT(m.id) DESC) AS actress_rank -- Rank based on the number of movies
FROM names n
-- Join to map names to roles
INNER JOIN role_mapping rm 
    ON n.id = rm.name_id
-- Join to fetch movie details
INNER JOIN movie m 
    ON m.id = rm.movie_id
-- Join to get movie ratings
INNER JOIN ratings r 
    ON r.movie_id = m.id
-- Join to identify the genre of movies
INNER JOIN genre g
    ON g.movie_id = m.id
-- Filter for actresses, high-rated movies, and drama genre
WHERE 
    r.avg_rating > 8 -- Only include movies with an average rating greater than 8
    AND rm.category = 'actress' -- Ensure the role is categorized as an actress
    AND g.genre = 'drama' -- Limit to movies in the 'drama' genre
-- Group results by actress name to aggregate their statistics
GROUP BY 
    n.name
-- Order by the count of movies in descending order to prioritize actresses with more movies
ORDER BY 
    movie_count DESC 
-- Limit results to the top 3 actresses
LIMIT 3;






/* Q29. Get the following details for top 9 directors (based on number of movies)
Director id
Name
Number of movies
Average inter movie duration in days
Average movie ratings
Total votes
Min rating
Max rating
total movie durations

Format:
+---------------+-------------------+---------------------+----------------------+--------------+--------------+------------+------------+----------------+
| director_id	|	director_name	|	number_of_movies  |	avg_inter_movie_days |	avg_rating	| total_votes  | min_rating	| max_rating | total_duration |
+---------------+-------------------+---------------------+----------------------+--------------+--------------+------------+------------+----------------+
|nm1777967		|	A.L. Vijay		|			5		  |	       177			 |	   5.65	    |	1754	   |	3.7		|	6.9		 |		613		  |
|	.			|		.			|			.		  |	       .			 |	   .	    |	.		   |	.		|	.		 |		.		  |
|	.			|		.			|			.		  |	       .			 |	   .	    |	.		   |	.		|	.		 |		.		  |
|	.			|		.			|			.		  |	       .			 |	   .	    |	.		   |	.		|	.		 |		.		  |
|	.			|		.			|			.		  |	       .			 |	   .	    |	.		   |	.		|	.		 |		.		  |
|	.			|		.			|			.		  |	       .			 |	   .	    |	.		   |	.		|	.		 |		.		  |
|	.			|		.			|			.		  |	       .			 |	   .	    |	.		   |	.		|	.		 |		.		  |
|	.			|		.			|			.		  |	       .			 |	   .	    |	.		   |	.		|	.		 |		.		  |
|	.			|		.			|			.		  |	       .			 |	   .	    |	.		   |	.		|	.		 |		.		  |
+---------------+-------------------+---------------------+----------------------+--------------+--------------+------------+------------+----------------+

--------------------------------------------------------------------------------------------*/
-- Type you code below:


-- create a view to calculate the average difference between two movie dates
CREATE VIEW avg_diff_between_movie_dates AS
WITH movie_dates AS (
    SELECT
        nm.id AS director_id,
        nm.name AS director_name,
        m.id AS movie_id,
        m.date_published AS movie_date,
        LEAD(m.date_published, 1) OVER (PARTITION BY nm.name ORDER BY m.date_published) AS next_movie_date
    FROM
        names nm
    INNER JOIN
        director_mapping dm ON nm.id = dm.name_id
    INNER JOIN
        movie m ON dm.movie_id = m.id
)
SELECT
    director_id,
    director_name,
    AVG(DATEDIFF(next_movie_date, movie_date)) AS avg_inter_movie_days
FROM
    movie_dates
GROUP BY
    director_id, director_name;
    
-- Top 9 directors based on the number of movies
WITH top_directors AS (
    SELECT
        nm.id AS director_id,
        nm.name AS director_name,
        COUNT(DISTINCT dm.movie_id) AS number_of_movies,
        ROUND(AVG(r.avg_rating), 2) AS avg_rating,
        SUM(r.total_votes) AS total_votes,
        MIN(r.avg_rating) AS min_rating,
        MAX(r.avg_rating) AS max_rating,
        SUM(m.duration) AS total_duration,
        ROW_NUMBER() OVER (ORDER BY COUNT(DISTINCT dm.movie_id) DESC) AS director_rank
    FROM
        names nm
    INNER JOIN
        director_mapping dm ON nm.id = dm.name_id
    INNER JOIN
        movie m ON dm.movie_id = m.id
    INNER JOIN
        ratings r ON m.id = r.movie_id
    GROUP BY
        director_id, director_name
)

-- Combine with the average inter-movie days
SELECT
    td.director_id,
    td.director_name,
    td.number_of_movies,
    AVGD.avg_inter_movie_days AS avg_inter_movie_days,
    td.avg_rating,
    td.total_votes,
    td.min_rating,
    td.max_rating,
    td.total_duration
FROM
    top_directors td
LEFT JOIN
    avg_diff_between_movie_dates AVGD ON td.director_id = AVGD.director_id
WHERE
    td.director_rank <= 9;